<template>
    <div>
        <!-- <button class="btn btn-primary mx-3 my-3" @click="showUsersF">Show users</button> -->
        <router-link to="/admin/users" class="btn btn-primary mx-3 my-3">Show users</router-link>
        <!-- <button class="btn btn-primary mx-3 my-3" @click="showRoomsF">Show rooms</button> -->
        <router-link to="/admin/rooms" class="btn btn-primary mx-3 my-3">Show rooms</router-link>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>