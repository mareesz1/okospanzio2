<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <div id="background" class="">
    <RouterView/>
  </div>
</template>

<style scoped>
  
</style>
