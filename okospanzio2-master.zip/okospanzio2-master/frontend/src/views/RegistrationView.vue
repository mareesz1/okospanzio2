<template>
    <div class="">
        <p class="display-1 text-center">Registration</p>
        <navbar/>
        <reg-component/>
    </div>
</template>

<script setup>
import navbar from '../components/NavbarComponent.vue';
import RegComponent from '../components/RegistrationComponent.vue';
</script>

<style lang="scss" scoped>

</style>